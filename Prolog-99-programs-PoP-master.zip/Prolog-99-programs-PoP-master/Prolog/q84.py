
print("Positive x and positive y : ",end="") 
print(pow(4, 3)) 

print("Negative x and positive y : ",end="") 
 
print(pow(-4, 3)) 

print("Positive x and negative y : ",end="") 
 
print(pow(4, -3)) 

print("Negative x and negative y : ",end="") 

print(pow(-4, -3)) 
