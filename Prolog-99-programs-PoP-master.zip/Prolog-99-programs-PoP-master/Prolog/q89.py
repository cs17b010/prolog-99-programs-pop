
#include <stdio.h> 

int main() 
{ 
	// initialising variables using Conditional Operator 
	int a = 20 > 10 ? 1 : 0; 

	// printing value of a 
	printf("The value of a is: %d", a); 
} 
