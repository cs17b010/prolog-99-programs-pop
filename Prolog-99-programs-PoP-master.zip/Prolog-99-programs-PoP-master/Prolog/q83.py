
n = 1
for i in range(1,5): 
	n=3*n 

print ("The value of 3**4 is : ",end="") 
print (n) 
