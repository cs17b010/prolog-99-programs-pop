

String1 = "GeeksForGeeks"
print("Initial String: ") 
print(String1) 


print("\nFirst character of String is: ") 
print(String1[0]) 

print("\nLast character of String is: ") 
print(String1[-1]) 



print("\nSlicing characters from 3-12: ") 
print(String1[3:12]) 

 
print("\nSlicing characters between " +
	"3rd and 2nd last character: ") 
print(String1[3:-2]) 
