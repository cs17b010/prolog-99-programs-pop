
def _sum(arr,n): 

    return(sum(arr)) 
 
arr=[] 

arr = [12, 3, 4, 15] 


n = len(arr) 
  
ans = _sum(arr,n) 
  
print (\'Sum of the array is \',ans) 
