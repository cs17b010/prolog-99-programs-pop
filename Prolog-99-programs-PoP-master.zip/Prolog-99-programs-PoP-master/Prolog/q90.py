
def fun(): 
	a = 1
	str = 'GeeksForGeeks'

print(fun.__code__.co_nlocals) 
